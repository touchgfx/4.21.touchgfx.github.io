#include <gui/template_screen/TemplatePresenter.hpp>
#include <gui/template_screen/TemplateView.hpp>

TemplatePresenter::TemplatePresenter(TemplateView& v)
    : view(v)
{
}

void TemplatePresenter::activate()
{

}

void TemplatePresenter::deactivate()
{

}
